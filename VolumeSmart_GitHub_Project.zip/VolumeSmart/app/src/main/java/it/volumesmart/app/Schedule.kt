package it.volumesmart.app

import org.json.JSONObject

data class Schedule(
    val id: Int,
    val name: String,
    val start: String,
    val end: String,
    val volume: Int,
    val enabled: Boolean = true
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("start", start)
        put("end", end); put("volume", volume); put("enabled", enabled)
    }

    companion object {
        fun fromJson(o: JSONObject) = Schedule(
            id = o.optInt("id"),
            name = o.optString("name", "Nuova fascia"),
            start = o.optString("start", "08:00"),
            end = o.optString("end", "09:00"),
            volume = o.optInt("volume", 50).coerceIn(0, 100),
            enabled = o.optBoolean("enabled", true)
        )
    }
}
