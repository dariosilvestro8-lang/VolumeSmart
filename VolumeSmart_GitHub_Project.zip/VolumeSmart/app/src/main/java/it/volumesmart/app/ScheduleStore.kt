package it.volumesmart.app

import android.content.Context
import org.json.JSONArray

object ScheduleStore {
    private const val PREFS = "volume_smart"
    private const val KEY_LIST = "schedules"
    private const val KEY_OFF_VOLUME = "off_volume"
    private const val KEY_THEME = "theme"

    fun get(context: Context): MutableList<Schedule> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY_LIST, "[]") ?: "[]"
        val array = JSONArray(raw)
        return MutableList(array.length()) { i -> Schedule.fromJson(array.getJSONObject(i)) }
    }

    fun save(context: Context, schedules: List<Schedule>) {
        val array = JSONArray()
        schedules.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY_LIST, array.toString()).apply()
    }

    fun offVolume(context: Context): Int =
        context.getSharedPreferences(PREFS, 0).getInt(KEY_OFF_VOLUME, 40)

    fun setOffVolume(context: Context, value: Int) {
        context.getSharedPreferences(PREFS, 0).edit().putInt(KEY_OFF_VOLUME, value.coerceIn(0, 100)).apply()
    }

    fun theme(context: Context): Int =
        context.getSharedPreferences(PREFS, 0).getInt(KEY_THEME, 0)

    fun setTheme(context: Context, value: Int) {
        context.getSharedPreferences(PREFS, 0).edit().putInt(KEY_THEME, value).apply()
    }
}
