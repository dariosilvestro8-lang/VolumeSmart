package it.volumesmart.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

class VolumeAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("schedule_id", -1)
        val isStart = intent.getBooleanExtra("is_start", false)
        val schedule = ScheduleStore.get(context).firstOrNull { it.id == id } ?: return
        if (!schedule.enabled) return

        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val percent = if (isStart) schedule.volume else ScheduleStore.offVolume(context)
        val target = (max * percent / 100f).toInt().coerceIn(0, max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)

        // Ripianifica l'evento per il giorno successivo.
        AlarmScheduler.scheduleNext(context, schedule, isStart)
    }
}
