package it.volumesmart.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object AlarmScheduler {
    fun scheduleAll(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        ScheduleStore.get(context).forEach { s ->
            cancel(context, s.id, true)
            cancel(context, s.id, false)
            if (!s.enabled) return@forEach
            scheduleNext(context, s, true)
            scheduleNext(context, s, false)
        }
    }

    fun scheduleNext(context: Context, schedule: Schedule, isStart: Boolean) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) return

        val time = runCatching {
            LocalTime.parse(if (isStart) schedule.start else schedule.end)
        }.getOrNull() ?: return

        var next = LocalDateTime.now().withHour(time.hour).withMinute(time.minute).withSecond(0).withNano(0)
        if (!next.isAfter(LocalDateTime.now())) next = next.plusDays(1)

        val intent = Intent(context, VolumeAlarmReceiver::class.java).apply {
            putExtra("schedule_id", schedule.id)
            putExtra("is_start", isStart)
        }
        val requestCode = schedule.id * 2 + if (isStart) 1 else 0
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        manager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(),
            pending
        )
    }

    fun cancel(context: Context, id: Int, isStart: Boolean) {
        val intent = Intent(context, VolumeAlarmReceiver::class.java)
        val requestCode = id * 2 + if (isStart) 1 else 0
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
            pending.cancel()
        }
    }
}
