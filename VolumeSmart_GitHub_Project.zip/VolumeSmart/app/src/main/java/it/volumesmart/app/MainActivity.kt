package it.volumesmart.app

import android.app.Activity
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val palettes = listOf(
        intArrayOf(Color.rgb(20, 16, 48), Color.rgb(90, 35, 130), Color.rgb(20, 130, 170)),
        intArrayOf(Color.rgb(255, 110, 80), Color.rgb(255, 70, 130), Color.rgb(120, 70, 220)),
        intArrayOf(Color.rgb(10, 100, 110), Color.rgb(25, 170, 150), Color.rgb(120, 210, 150)),
        intArrayOf(Color.rgb(35, 45, 90), Color.rgb(60, 90, 180), Color.rgb(150, 90, 210))
    )
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) AlarmScheduler.scheduleAll(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        askExactAlarmIfNeeded()
        AlarmScheduler.scheduleAll(this)
    }

    private fun buildUi() {
        val palette = palettes[ScheduleStore.theme(this).coerceIn(palettes.indices)]
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, palette).apply { cornerRadius = dp(0).toFloat() }
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        root.addView(label("VOLUME SMART", 13, Color.WHITE, true))
        root.addView(label("Il tuo volume,\nsecondo i tuoi orari.", 30, Color.WHITE, true).apply {
            setPadding(0, dp(12), 0, dp(8))
        })
        root.addView(label("Automatizza il volume del telefono con le tue regole.", 14, 0xFFE9E5F5.toInt(), false))

        status = label("● Programmazione pronta", 13, Color.WHITE, true).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0x33FFFFFF, 18)
        }
        val statusWrap = LinearLayout(this).apply {
            setPadding(0, dp(18), 0, dp(18))
            addView(status)
        }
        root.addView(statusWrap)

        root.addView(label("LE TUE FASCE ORARIE", 13, Color.WHITE, true).apply {
            setPadding(0, dp(10), 0, dp(12))
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        val add = button("+  Aggiungi una fascia", 0xFFFFFFFF.toInt(), 0xFF32205E.toInt()) {
            editSchedule(null)
        }
        root.addView(add, matchWrap(dp(54)).apply { topMargin = dp(16) })

        root.addView(label("VOLUME FUORI FASCIA", 13, Color.WHITE, true).apply {
            setPadding(0, dp(28), 0, dp(8))
        })
        val off = SeekBar(this).apply {
            max = 100
            progress = ScheduleStore.offVolume(this@MainActivity)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) offText.text = "$progress%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    ScheduleStore.setOffVolume(this@MainActivity, seekBar?.progress ?: 40)
                }
            })
        }
        val offText = label("${off.progress}%", 18, Color.WHITE, true)
        root.addView(offText)
        root.addView(off)

        root.addView(label("PERSONALIZZA LO SFONDO", 13, Color.WHITE, true).apply {
            setPadding(0, dp(28), 0, dp(10))
        })
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        palettes.forEachIndexed { index, colors ->
            val swatch = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(14).toFloat() }
                setOnClickListener {
                    ScheduleStore.setTheme(this@MainActivity, index)
                    buildUi()
                }
            }
            themes.addView(swatch, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                marginEnd = dp(8)
            })
        }
        root.addView(themes)
        root.addView(label("Nota: il volume gestito è quello multimediale. Per il silenzioso totale Android richiede autorizzazioni aggiuntive.", 12, 0xFFE9E5F5.toInt(), false).apply {
            setPadding(0, dp(24), 0, 0)
        })

        refreshSchedules()
    }

    private fun refreshSchedules() {
        list.removeAllViews()
        val schedules = ScheduleStore.get(this)
        if (schedules.isEmpty()) {
            list.addView(label("Nessuna fascia ancora. Creane una per iniziare.", 14, Color.WHITE, false).apply {
                setPadding(dp(14), dp(16), dp(14), dp(16))
                background = rounded(0x22FFFFFF, 16)
            })
        }
        schedules.forEach { s ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(12))
                background = rounded(0x30FFFFFF, 20)
            }
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val title = label(s.name, 17, Color.WHITE, true)
            top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            val toggle = Switch(this).apply {
                isChecked = s.enabled
                buttonTintListCompat()
                setOnCheckedChangeListener { _, checked ->
                    val updated = ScheduleStore.get(this@MainActivity).map {
                        if (it.id == s.id) it.copy(enabled = checked) else it
                    }
                    ScheduleStore.save(this@MainActivity, updated)
                    AlarmScheduler.scheduleAll(this@MainActivity)
                    refreshSchedules()
                }
            }
            top.addView(toggle)
            card.addView(top)
            card.addView(label("${s.start}  →  ${s.end}     •     Volume ${s.volume}%", 14, 0xFFF2ECFF.toInt(), false).apply {
                setPadding(0, dp(5), 0, dp(10))
            })
            val actions = LinearLayout(this).apply { gravity = Gravity.END }
            actions.addView(textAction("Modifica") { editSchedule(s) })
            actions.addView(textAction("Elimina") {
                ScheduleStore.save(this@MainActivity, ScheduleStore.get(this@MainActivity).filterNot { it.id == s.id })
                AlarmScheduler.cancel(this@MainActivity, s.id, true)
                AlarmScheduler.cancel(this@MainActivity, s.id, false)
                refreshSchedules()
            })
            card.addView(actions)
            list.addView(card, matchWrap().apply { bottomMargin = dp(10) })
        }
    }

    private fun editSchedule(existing: Schedule?) {
        val name = EditText(this).apply {
            hint = "Nome (es. Notte, Lavoro)"
            setSingleLine()
            setText(existing?.name ?: "")
        }
        val start = Button(this).apply { text = "Inizio: ${existing?.start ?: "08:00"}" }
        val end = Button(this).apply { text = "Fine: ${existing?.end ?: "09:00"}" }
        var startValue = existing?.start ?: "08:00"
        var endValue = existing?.end ?: "09:00"
        start.setOnClickListener { pickTime(startValue) { startValue = it; start.text = "Inizio: $it" } }
        end.setOnClickListener { pickTime(endValue) { endValue = it; end.text = "Fine: $it" } }
        val seek = SeekBar(this).apply { max = 100; progress = existing?.volume ?: 50 }
        val value = label("${seek.progress}%", 18, Color.BLACK, true)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { value.text = "$p%" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(name)
            addView(start)
            addView(end)
            addView(label("Volume da applicare", 14, Color.DKGRAY, true))
            addView(value)
            addView(seek)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Nuova fascia" else "Modifica fascia")
            .setView(content)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Salva") { _, _ ->
                val n = name.text.toString().trim().ifBlank { "La mia fascia" }
                val id = existing?.id ?: ((ScheduleStore.get(this).maxOfOrNull { it.id } ?: 0) + 1)
                val updated = Schedule(id, n, startValue, endValue, seek.progress)
                val all = ScheduleStore.get(this).filterNot { it.id == id }.toMutableList().apply { add(updated) }
                ScheduleStore.save(this, all)
                AlarmScheduler.scheduleAll(this)
                refreshSchedules()
                askExactAlarmIfNeeded()
            }.show()
    }

    private fun pickTime(current: String, onPicked: (String) -> Unit) {
        val parts = current.split(":")
        TimePickerDialog(this, { _, h, m ->
            onPicked(String.format(Locale.getDefault(), "%02d:%02d", h, m))
        }, parts[0].toInt(), parts[1].toInt(), true).show()
    }

    private fun askExactAlarmIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!manager.canScheduleExactAlarms()) {
                status.text = "● Consenti gli allarmi esatti per attivare gli orari"
                status.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName")))
                }
            }
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, bg: Int, fg: Int, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(fg)
        background = rounded(bg, 18)
        setOnClickListener { action() }
    }

    private fun textAction(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        setPadding(dp(12), dp(6), dp(8), dp(6))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap(height: Int = -2) = LinearLayout.LayoutParams(-1, height)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun Switch.buttonTintListCompat() {
        if (Build.VERSION.SDK_INT >= 21) {
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            trackTintList = android.content.res.ColorStateList.valueOf(0x88FFFFFF.toInt())
        }
    }
}
